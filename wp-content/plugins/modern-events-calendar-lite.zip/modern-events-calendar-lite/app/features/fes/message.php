<?php
/** no direct access **/
defined('MECEXEC') or die();
?>
<div class="mec-fes-message">
    <p><?php echo $message; ?></p>
</div>