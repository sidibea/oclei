// server setup

var wplc_baseurl = config.baseurl;
var WPLC_SOCKET_URI = config.serverurl;
